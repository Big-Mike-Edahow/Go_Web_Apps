/* helpers.go */

package main

func getOneBook(id int) (Book, error) {
	row, err := DB.Query("SELECT id, isbn, title, author, excerpt, price FROM books WHERE id = ?", id)
	if err != nil {
		panic(err.Error())
	}
	defer row.Close()

	var book Book
	for row.Next() {
		err = row.Scan(&book.Id, &book.Isbn, &book.Title, &book.Author, &book.Excerpt, &book.Price)
		if err != nil {
			panic(err.Error())
		}
	}
	return book, err
}

func getAllBooks() ([]Book, error) {
	rows, err := DB.Query("SELECT * FROM books")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var books []Book
	for rows.Next() {
		var book Book
		err := rows.Scan(&book.Id, &book.Isbn, &book.Title, &book.Author, &book.Excerpt, &book.Price)
		if err != nil {
			return nil, err
		}
		books = append(books, book)
	}
	if err = rows.Err(); err != nil {
		return nil, err
	}
	return books, nil
}
